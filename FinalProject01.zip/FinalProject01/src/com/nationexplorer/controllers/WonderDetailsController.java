package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.util.List;

public class WonderDetailsController {

    @FXML
    private Label countryNameLabel;
    @FXML
    private ListView<String> wondersListView;
    @FXML
    private Label wonderDetailsLabel;

    private Country selectedCountry;

    public void setCountry(Country country) {
        this.selectedCountry = country;
        countryNameLabel.setText(country.getName());

        List<String> wonders = country.getPointsOfInterest();
        wondersListView.getItems().addAll(wonders);

        wondersListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                // Display details of the selected wonder
                wonderDetailsLabel.setText(newValue);
            }
        });
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nationexplorer/fxml/WondersScreen.fxml"));
        Parent root = loader.load();

        WondersController controller = loader.getController();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}



