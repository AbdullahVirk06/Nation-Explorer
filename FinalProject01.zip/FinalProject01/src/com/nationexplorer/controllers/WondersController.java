package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class WondersController {

    @FXML
    private ListView<String> countryListView;

    private List<Country> countries = Arrays.asList(
            new Country("China", "Beijing", "18 trillion USD", "Chinese", "1.4 billion", "2.5 million", Arrays.asList("Great Wall of China", "Temple of Heaven")),
            new Country("India", "New Delhi", "3 trillion USD", "Hindi", "1.4 billion", "1.4 million", Arrays.asList("Taj Mahal", "Qutub Minar")),
            new Country("Pakistan", "Islamabad", "347 billion USD", "Urdu", "235 million", "650 Thousand", Arrays.asList("K-2 (Mount Godwin Austen)", "Karakoram Highway")),
            new Country("Japan", "Tokyo", "4.9 trillion USD", "Japanese", "125.8 million", "240 thousand", Arrays.asList("Mount Fuji", "Tokyo Skytree")),
            new Country("France", "Paris", "2.78 trillion USD", "French", "67.1 million", "203 thousand", Arrays.asList("Eiffel Tower", "Palace of Versailles")),
            new Country("USA", "Washington, D.C.", "23 trillion USD", "English", "331 million", "1.4 million", Arrays.asList("Las Vegas", "Los Angeles")),
            new Country("UK", "London", "3.19 trillion USD", "English", "67.2 million", "148 thousand", Arrays.asList("Edinburgh", "Big Ben"))
    );

    @FXML
    public void initialize() {
        ObservableList<String> countryNames = FXCollections.observableArrayList();
        for (Country country : countries) {
            countryNames.add(country.getName());
        }
        countryListView.setItems(countryNames);

        countryListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                Country selectedCountry = getCountryByName(newValue);
                if (selectedCountry != null) {
                    try {
                        showWonderDetailsScreen(selectedCountry);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private Country getCountryByName(String name) {
        for (Country country : countries) {
            if (country.getName().equals(name)) {
                return country;
            }
        }
        return null;
    }

    private void showWonderDetailsScreen(Country country) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nationexplorer/fxml/WonderDetailsScreen.fxml"));
        Parent root = loader.load();

        WonderDetailsController controller = loader.getController();
        controller.setCountry(country);

        Stage stage = (Stage) countryListView.getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/nationexplorer/fxml/MainScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}





