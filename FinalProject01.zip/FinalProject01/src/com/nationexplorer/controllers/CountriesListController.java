package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CountriesListController {

    @FXML
    private TextField searchField;

    @FXML
    private ListView<String> countriesListView;

    private ObservableList<Country> countries;

    @FXML
    public void initialize() {
        // Initialize the list of countries
        countries = FXCollections.observableArrayList(
                new Country("China", "Capital-Beijing", "GDP-18 trillion USD", "Language-Chinese", "Population-1.4 billion", "Military Strength-2.5 Million", Arrays.asList("Great Wall of China", "Temple of Heaven", "Forbidden City", "Summer Palace")),
                new Country("India", "Capital-New Delhi", "GDP-3 trillion USD", "Language-Hindi", "Population-1.4 billion", "Military Strength-1.4 Million", Arrays.asList("Taj Mahal", "Qutub Minar", "India Gate", "Red Fort")),
                new Country("Pakistan", "Capital-Islamabad", "GDP-347 billion USD", "Language-Urdu", "Population-235 million", "Military Strength-650 Thousand", Arrays.asList("K-2 (Mount Godwin Austen)", "Karakoram Highway", "Badshahi Mosque", "Mohenjo-daro")),
                new Country("Japan", "Capital-Tokyo", "GDP-4.9 trillion USD", "Language-Japanese", "Population-125.8 million", "Military Strength-240 Thousand", Arrays.asList("Mount Fuji", "Tokyo Skytree", "Fushimi Inari Shrine", "Osaka Castle")),
                new Country("France", "Capital-Paris", "GDP-2.78 trillion USD", "Language-French", "Population-67.1 million", "Military Strength-203 Thousand", Arrays.asList("Eiffel Tower", "Palace of Versailles", "Louvre Museum", "Mont Saint-Michel")),
                new Country("USA", "Capital-Washington, D.C.", "GDP-23 trillion USD", "Language-English", "Population-331 million", "Military Strength-1.4 Million", Arrays.asList("Las Vegas", "Los Angeles", "New York City", "Grand Canyon")),
                new Country("UK", "Capital-London", "GDP-3.19 trillion USD", "Language-English", "Population-67.2 million", "Military Strength-148 Thousand", Arrays.asList("Edinburgh", "Big Ben", "Tower of London", "Stonehenge")),
                new Country("Germany", "Capital-Berlin", "GDP-4.2 trillion USD", "Language-German", "Population-83.2 million", "Military Strength-184 Thousand", Arrays.asList("Dresden", "Cologne Cathedral", "Neuschwanstein Castle", "Brandenburg Gate")),
                new Country("Spain", "Capital-Madrid", "GDP-1.43 trillion USD", "Language-Spanish", "Population-47.4 million", "Military Strength-123 Thousand", Arrays.asList("Barcelona", "Santa Iglesia Cathedral Primada de Toledo", "Sagrada Familia", "Alhambra")),
                new Country("Italy", "Capital-Rome", "GDP-2.1 trillion USD", "Language-Italian", "Population-59.6 million", "Military Strength-165 Thousand", Arrays.asList("Colosseum", "St. Peter's Basilica", "Leaning Tower of Pisa", "Venice Canals")),
                new Country("Switzerland", "Capital-Bern", "GDP-824 billion USD", "Languages-German, French, Italian", "Population-8.7 million", "Military Strength-20 Thousand", Arrays.asList("The Matterhorn", "Swiss National Park", "Lake Geneva", "Chateau de Chillon")),
                new Country("Netherlands", "Capital-Amsterdam", "GDP-1.1 trillion USD", "Language-Dutch", "Population-17.5 million", "Military Strength-42 Thousand", Arrays.asList("Royal Palace Amsterdam", "Keukenhof", "Rijksmuseum", "Van Gogh Museum")),
                new Country("Brazil", "Capital-Brasília", "GDP-2.05 trillion USD", "Language-Portuguese", "Population-213 million", "Military Strength-334 Thousand", Arrays.asList("Christ the Redeemer", "Amazon Rainforest", "Sugarloaf Mountain", "Iguazu Falls")),
                new Country("Australia", "Capital-Canberra", "GDP-1.65 trillion USD", "Language-English", "Population-25.7 million", "Military Strength-59 Thousand", Arrays.asList("Sydney Opera House", "Great Barrier Reef", "Uluru", "Bondi Beach")),
                new Country("Canada", "Capital-Ottawa", "GDP-2.02 trillion USD", "Languages-English, French", "Population-38.2 million", "Military Strength-71 Thousand", Arrays.asList("Niagara Falls", "Banff National Park", "CN Tower", "Old Quebec"))
        );

        // Populate the ListView with country names
        ObservableList<String> countryNames = FXCollections.observableArrayList();
        for (Country country : countries) {
            countryNames.add(country.getName());
        }
        countriesListView.setItems(countryNames);
        searchField.addEventFilter(KeyEvent.KEY_RELEASED, event -> filterCountries());
    }
    private void filterCountries() {
        String filter = searchField.getText().toLowerCase();
        List<String> filteredCountries = countries.stream()
                .map(Country::getName)
                .filter(name -> name.toLowerCase().contains(filter))
                .collect(Collectors.toList());
        countriesListView.setItems(FXCollections.observableArrayList(filteredCountries));
    }

    @FXML
    private void handleCountrySelect(MouseEvent event) throws IOException {
        // Get selected country name
        String selectedCountryName = countriesListView.getSelectionModel().getSelectedItem();
        if (selectedCountryName != null) {
            Country selectedCountry = countries.stream()
                    .filter(country -> country.getName().equals(selectedCountryName))
                    .findFirst()
                    .orElse(null);

            if (selectedCountry != null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nationexplorer/fxml/CountryDetail.fxml"));
                Parent root = loader.load();

                CountryDetailController controller = loader.getController();
                controller.setCountry(selectedCountry);

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        // Load the MainScreen.fxml screen
        Parent root = FXMLLoader.load(getClass().getResource("/com/nationexplorer/fxml/MainScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}





