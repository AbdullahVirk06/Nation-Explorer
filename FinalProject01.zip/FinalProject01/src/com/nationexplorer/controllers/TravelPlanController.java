package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TravelPlanController {

    @FXML
    private TextField budgetField;

    @FXML
    private ComboBox<String> luxuryComboBox;

    @FXML
    private ComboBox<String> weatherComboBox;

    @FXML
    private ListView<String> suggestionsListView;

    private ObservableList<Country> countries;

    @FXML
    public void initialize() {
        // Initialize the list of countries
        countries = FXCollections.observableArrayList(
                new Country("China", "Beijing", "18 trillion USD", "Chinese", "1.4 billion","2.5 Million", Collections.emptyList()),
                new Country("India", "New Delhi", "3 trillion USD", "Hindi", "1.4 billion", "1.4 Million",Collections.emptyList()),
                new Country("Pakistan", "Islamabad", "347 billion USD", "Urdu", "235 million", "650 Thousand",Collections.emptyList()),
                new Country("Japan", "Tokyo", "4.9 trillion USD", "Japanese", "125.8 million", "240 thousand", Collections.emptyList()),
                new Country("France", "Paris", "2.78 trillion USD", "French", "67.1 million", "203 thousand", Collections.emptyList()),
                new Country("USA", "Washington, D.C.", "23 trillion USD", "English", "331 million", "1.4 million", Collections.emptyList()),
                new Country("UK", "London", "3.19 trillion USD", "English", "67.2 million", "148 thousand", Collections.emptyList()),
                new Country("Germany", "Berlin", "4.2 trillion USD", "German", "83.2 million", "184 thousand",Collections.emptyList()),
                new Country("Spain", "Madrid", "1.43 trillion USD", "Spanish", "47.4 million", "123 thousand",Collections.emptyList()),
                new Country("Italy", "Rome", "2.1 trillion USD", "Italian", "59.6 million", "165 thousand",Collections.emptyList()),
                new Country("Switzerland", "Bern", "824 billion USD", "German, French, Italian", "8.7 million", "20 thousand",Collections.emptyList()),
                new Country("Netherlands", "Amsterdam", "1.1 trillion USD", "Dutch", "17.5 million", "42 thousand",Collections.emptyList()),
                new Country("Brazil", "Brasília", "2.05 trillion USD", "Portuguese", "213 million", "334 thousand", Collections.emptyList()),
                new Country("Australia", "Canberra", "1.65 trillion USD", "English", "25.7 million", "59 thousand",Collections.emptyList()),
                new Country("Canada", "Ottawa", "2.02 trillion USD", "English, French", "38.2 million", "71 thousand", Collections.emptyList())
                // Add more countries here
        );

        // Set default values for ComboBoxes
        luxuryComboBox.setItems(FXCollections.observableArrayList("Standard", "Deluxe", "Luxury"));
        weatherComboBox.setItems(FXCollections.observableArrayList("Sunny", "Rainy", "Snowy"));
    }

    @FXML
    private void handleGetSuggestions(ActionEvent event) {
        // Get user inputs
        String budgetStr = budgetField.getText();
        String luxury = luxuryComboBox.getValue();
        String weather = weatherComboBox.getValue();

        // Validate budget
        double budget;
        try {
            budget = Double.parseDouble(budgetStr);
            if (budget < 1000 || budget > 50000) {
                showAlert("Invalid Budget", "Please enter a budget between $1,000 and $50,000.");
                return;
            }
        } catch (NumberFormatException e) {
            showAlert("Invalid Budget", "Please enter a valid number for the budget.");
            return;
        }

        // Perform logic to filter and suggest countries (simplified example)
        List<Country> suggestions = new ArrayList<>(countries);
        Collections.shuffle(suggestions); // Randomize the list

        // Limit to  3 suggestions
        List<Country> topSuggestions = suggestions.subList(0, Math.min(3, suggestions.size()));

        // Display suggestions in the ListView
        ObservableList<String> suggestionNames = FXCollections.observableArrayList();
        for (Country country : topSuggestions) {
            suggestionNames.add(country.getName());
        }
        suggestionsListView.setItems(suggestionNames);
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        // Load the MainScreen.fxml screen
        Parent root = FXMLLoader.load(getClass().getResource("/com/nationexplorer/fxml/MainScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}







