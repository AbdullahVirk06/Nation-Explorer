package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class CountryDetailController {

    @FXML
    private Label nameLabel;
    @FXML
    private Label capitalLabel;
    @FXML
    private Label gdpLabel;
    @FXML
    private Label languageLabel;
    @FXML
    private Label populationLabel;
    @FXML
    private Label militaryStrengthLabel;

    private Country selectedCountry;

    public void setCountry(Country country) {
        this.selectedCountry = country;
        nameLabel.setText(country.getName());
        capitalLabel.setText(country.getCapital());
        gdpLabel.setText(country.getGdp());
        languageLabel.setText(country.getLanguage());
        populationLabel.setText(country.getPopulation());
        militaryStrengthLabel.setText(country.getMilitaryStrength());
    }

    @FXML
    private void handlePointOfInterest(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nationexplorer/fxml/PointOfInterest.fxml"));
        Parent root = loader.load();

        PointOfInterestController controller = loader.getController();
        controller.setCountry(selectedCountry);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/nationexplorer/fxml/CountriesList.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleLabelClick(MouseEvent event) {
        Label clickedLabel = (Label) event.getSource();
        String labelInfo = "";

        switch (clickedLabel.getId()) {
            case "capitalLabel":
                labelInfo = "Capital: " + selectedCountry.getCapital();
                break;
            case "gdpLabel":
                labelInfo = "GDP: " + selectedCountry.getGdp();
                break;
            case "languageLabel":
                labelInfo = "Language: " + selectedCountry.getLanguage();
                break;
            case "populationLabel":
                labelInfo = "Population: " + selectedCountry.getPopulation();
                break;
            case "militaryStrengthLabel":
                labelInfo = "Military Strength: " + selectedCountry.getMilitaryStrength();
                break;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Country Information");
        alert.setHeaderText(null);
        alert.setContentText(labelInfo);
        alert.showAndWait();
    }
}






