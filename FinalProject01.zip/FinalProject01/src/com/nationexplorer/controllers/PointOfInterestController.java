package com.nationexplorer.controllers;

import com.nationexplorer.models.Country;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.io.IOException;

public class PointOfInterestController {

    @FXML
    private Label destination1;
    @FXML
    private Label destination2;
    @FXML
    private Label destination3;
    // Add more labels if needed

    private Country selectedCountry;

    public void setCountry(Country country) {
        this.selectedCountry = country;
        // Setting points of interest dynamically
        if (country.getPointsOfInterest().size() > 0) destination1.setText(country.getPointsOfInterest().get(0));
        if (country.getPointsOfInterest().size() > 1) destination2.setText(country.getPointsOfInterest().get(1));
        if (country.getPointsOfInterest().size() > 2) destination3.setText(country.getPointsOfInterest().get(2));
        //if (country.getPointsOfInterest().size() > 3) destination3.setText(country.getPointsOfInterest().get(3));
        // Add more if needed
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nationexplorer/fxml/CountryDetail.fxml"));
        Parent root = loader.load();

        CountryDetailController controller = loader.getController();
        controller.setCountry(selectedCountry);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}

