package com.nationexplorer.models;

import java.util.List;

public class Country {
    private String name;
    private String capital;
    private String gdp;
    private String language;
    private String population;
    private String militaryStrength;
    //private List<String> wonders;
    private List<String> pointsOfInterest;

    public Country(String name, String capital, String gdp, String language, String population, String militaryStrength,  List<String> pointsOfInterest) {
        this.name = name;
        this.capital = capital;
        this.gdp = gdp;
        this.language = language;
        this.population = population;
        this.militaryStrength = militaryStrength;
        //this.wonders = wonders;
        this.pointsOfInterest = pointsOfInterest;
    }

    public String getName() {
        return name;
    }

    public String getCapital() {
        return capital;
    }

    public String getGdp() {
        return gdp;
    }

    public String getLanguage() {
        return language;
    }

    public String getPopulation() {
        return population;
    }

    public String getMilitaryStrength() {
        return militaryStrength;
    }

    /*public List<String> getWonders() {
        return wonders;
    }*/

    public List<String> getPointsOfInterest() {
        return pointsOfInterest;
    }
}

